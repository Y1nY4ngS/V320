﻿using System;
class Program
{
    static void BerechneSteuer(double einkommen)
    {
        if (einkommen < 2400)
        {
            Console.WriteLine("Keine Steuer zu verbuchen");
        } else
        {
            double tax = (einkommen - 2400) * .25;
            Console.WriteLine($"Das zu versteuernde Betrag ist {tax}");
        }
            
    }
    static void FirmaSteuer(double gewinn)
    {
        double tax = gewinn * .07;
        Console.WriteLine($"Das zu versteuernde Gewinn ist {tax}");
    }
    static void Main(string[] args)
    {
        BerechneSteuer(6400);
        BerechneSteuer(36000);
        BerechneSteuer(4000000);
        FirmaSteuer(500000);
    }
}